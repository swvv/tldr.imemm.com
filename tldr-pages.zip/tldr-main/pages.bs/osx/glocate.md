# glocate

> Ova komanda je pseudonim za `-p linux locate`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux locate`
