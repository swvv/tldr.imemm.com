# gbase64

> Ova komanda je pseudonim za `-p linux base64`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux base64`
