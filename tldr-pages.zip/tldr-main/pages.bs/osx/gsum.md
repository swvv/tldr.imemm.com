# gsum

> Ova komanda je pseudonim za `-p linux sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sum`
