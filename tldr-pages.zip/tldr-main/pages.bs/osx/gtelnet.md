# gtelnet

> Ova komanda je pseudonim za `-p linux telnet`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux telnet`
