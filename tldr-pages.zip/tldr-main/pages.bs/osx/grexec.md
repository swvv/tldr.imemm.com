# grexec

> Ova komanda je pseudonim za `-p linux rexec`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux rexec`
