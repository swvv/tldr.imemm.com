# gchmod

> Ova komanda je pseudonim za `-p linux chmod`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux chmod`
