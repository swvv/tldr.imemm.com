# gb2sum

> Ova komanda je pseudonim za `-p linux b2sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux b2sum`
