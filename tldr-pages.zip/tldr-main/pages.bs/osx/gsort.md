# gsort

> Ova komanda je pseudonim za `-p linux sort`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sort`
