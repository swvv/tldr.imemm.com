# gcsplit

> Ova komanda je pseudonim za `-p linux csplit`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux csplit`
