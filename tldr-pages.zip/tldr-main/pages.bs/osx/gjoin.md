# gjoin

> Ova komanda je pseudonim za `-p linux join`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux join`
