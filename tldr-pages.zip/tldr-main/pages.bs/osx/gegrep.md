# gegrep

> Ova komanda je pseudonim za `-p linux egrep`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux egrep`
