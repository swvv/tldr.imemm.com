# gshuf

> Ova komanda je pseudonim za `-p linux shuf`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux shuf`
