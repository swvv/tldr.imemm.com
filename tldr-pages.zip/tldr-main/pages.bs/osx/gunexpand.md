# gunexpand

> Ova komanda je pseudonim za `-p linux unexpand`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux unexpand`
