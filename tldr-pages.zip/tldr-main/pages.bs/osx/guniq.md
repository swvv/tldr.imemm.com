# guniq

> Ova komanda je pseudonim za `-p linux uniq`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux uniq`
