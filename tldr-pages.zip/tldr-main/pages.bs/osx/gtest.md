# gtest

> Ova komanda je pseudonim za `-p linux test`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux test`
