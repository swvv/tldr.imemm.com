# gping6

> Ova komanda je pseudonim za `-p linux ping6`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux ping6`
