# gsha512sum

> Ova komanda je pseudonim za `-p linux sha512sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sha512sum`
