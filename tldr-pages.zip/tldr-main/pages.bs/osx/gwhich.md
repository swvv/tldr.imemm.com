# gwhich

> Ova komanda je pseudonim za `-p linux which`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux which`
