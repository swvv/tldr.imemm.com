# gsplit

> Ova komanda je pseudonim za `-p linux split`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux split`
