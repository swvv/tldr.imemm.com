# gfalse

> Ova komanda je pseudonim za `-p linux false`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux false`
