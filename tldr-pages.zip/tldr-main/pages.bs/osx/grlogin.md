# grlogin

> Ova komanda je pseudonim za `-p linux rlogin`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux rlogin`
