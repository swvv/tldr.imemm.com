# gawk

> Ova komanda je pseudonim za `-p linux awk`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux awk`
