# guname

> Ova komanda je pseudonim za `-p linux uname`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux uname`
