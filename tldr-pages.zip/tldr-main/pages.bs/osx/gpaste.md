# gpaste

> Ova komanda je pseudonim za `-p linux paste`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux paste`
