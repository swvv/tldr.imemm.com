# gpinky

> Ova komanda je pseudonim za `-p linux pinky`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux pinky`
