# gfind

> Ova komanda je pseudonim za `-p linux find`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux find`
