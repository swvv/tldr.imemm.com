# gunits

> Ova komanda je pseudonim za `-p linux units`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux units`
