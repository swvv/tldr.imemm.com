# ghostname

> Ova komanda je pseudonim za `-p linux hostname`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux hostname`
