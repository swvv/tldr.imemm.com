# gsha256sum

> Ova komanda je pseudonim za `-p linux sha256sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sha256sum`
