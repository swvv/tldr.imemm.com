# genv

> Ova komanda je pseudonim za `-p linux env`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux env`
