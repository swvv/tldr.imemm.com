# gstty

> Ova komanda je pseudonim za `-p linux stty`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux stty`
