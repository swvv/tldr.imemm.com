# gsync

> Ova komanda je pseudonim za `-p linux sync`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sync`
