# gsha384sum

> Ova komanda je pseudonim za `-p linux sha384sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sha384sum`
