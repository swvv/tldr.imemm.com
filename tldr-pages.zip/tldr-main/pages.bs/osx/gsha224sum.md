# gsha224sum

> Ova komanda je pseudonim za `-p linux sha224sum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux sha224sum`
