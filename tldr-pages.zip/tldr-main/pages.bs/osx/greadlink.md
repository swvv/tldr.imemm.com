# greadlink

> Ova komanda je pseudonim za `-p linux readlink`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux readlink`
