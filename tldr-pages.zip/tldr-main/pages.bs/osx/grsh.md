# grsh

> Ova komanda je pseudonim za `-p linux rsh`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux rsh`
