# gfmt

> Ova komanda je pseudonim za `-p linux fmt`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux fmt`
