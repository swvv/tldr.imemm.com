# glibtool

> Ova komanda je pseudonim za `-p linux libtool`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux libtool`
