# gyes

> Ova komanda je pseudonim za `-p linux yes`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux yes`
