# gcksum

> Ova komanda je pseudonim za `-p linux cksum`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux cksum`
