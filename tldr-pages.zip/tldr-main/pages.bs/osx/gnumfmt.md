# gnumfmt

> Ova komanda je pseudonim za `-p linux numfmt`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux numfmt`
