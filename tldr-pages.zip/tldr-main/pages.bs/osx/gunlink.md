# gunlink

> Ova komanda je pseudonim za `-p linux unlink`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux unlink`
