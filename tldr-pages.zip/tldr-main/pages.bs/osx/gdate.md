# gdate

> Ova komanda je pseudonim za `-p linux date`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux date`
