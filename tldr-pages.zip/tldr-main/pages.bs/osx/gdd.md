# gdd

> Ova komanda je pseudonim za `-p linux dd`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux dd`
