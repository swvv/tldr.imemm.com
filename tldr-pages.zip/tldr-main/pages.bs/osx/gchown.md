# gchown

> Ova komanda je pseudonim za `-p linux chown`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux chown`
