# gexpand

> Ova komanda je pseudonim za `-p linux expand`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux expand`
