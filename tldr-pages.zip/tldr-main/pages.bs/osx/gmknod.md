# gmknod

> Ova komanda je pseudonim za `-p linux mknod`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux mknod`
