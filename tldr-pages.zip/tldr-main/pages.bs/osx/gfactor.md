# gfactor

> Ova komanda je pseudonim za `-p linux factor`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux factor`
