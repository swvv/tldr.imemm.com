# gcomm

> Ova komanda je pseudonim za `-p linux comm`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux comm`
