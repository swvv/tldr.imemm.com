# grmdir

> Ova komanda je pseudonim za `-p linux rmdir`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux rmdir`
