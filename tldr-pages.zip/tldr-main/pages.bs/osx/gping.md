# gping

> Ova komanda je pseudonim za `-p linux ping`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux ping`
