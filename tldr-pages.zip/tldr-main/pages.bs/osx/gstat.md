# gstat

> Ova komanda je pseudonim za `-p linux stat`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux stat`
