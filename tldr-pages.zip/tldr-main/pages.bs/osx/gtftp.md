# gtftp

> Ova komanda je pseudonim za `-p linux tftp`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux tftp`
