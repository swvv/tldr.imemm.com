# gdf

> Ova komanda je pseudonim za `-p linux df`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux df`
