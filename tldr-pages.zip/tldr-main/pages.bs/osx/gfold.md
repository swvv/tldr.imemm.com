# gfold

> Ova komanda je pseudonim za `-p linux fold`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux fold`
