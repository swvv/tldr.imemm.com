# gmv

> Ova komanda je pseudonim za `-p linux mv`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux mv`
