# gchroot

> Ova komanda je pseudonim za `-p linux chroot`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux chroot`
