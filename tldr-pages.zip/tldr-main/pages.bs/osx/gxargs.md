# gxargs

> Ova komanda je pseudonim za `-p linux xargs`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux xargs`
