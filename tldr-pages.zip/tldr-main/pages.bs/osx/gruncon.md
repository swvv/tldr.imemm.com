# gruncon

> Ova komanda je pseudonim za `-p linux runcon`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux runcon`
