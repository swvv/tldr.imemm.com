# god

> Ova komanda je pseudonim za `-p linux od`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux od`
