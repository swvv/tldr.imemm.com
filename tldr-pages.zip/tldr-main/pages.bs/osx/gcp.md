# gcp

> Ova komanda je pseudonim za `-p linux cp`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux cp`
