# gtruncate

> Ova komanda je pseudonim za `-p linux truncate`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux truncate`
