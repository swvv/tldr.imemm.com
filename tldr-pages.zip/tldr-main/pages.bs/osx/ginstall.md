# ginstall

> Ova komanda je pseudonim za `-p linux install`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux install`
