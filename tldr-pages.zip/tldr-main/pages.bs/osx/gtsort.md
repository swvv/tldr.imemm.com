# gtsort

> Ova komanda je pseudonim za `-p linux tsort`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux tsort`
