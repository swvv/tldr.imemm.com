# gupdatedb

> Ova komanda je pseudonim za `-p linux updatedb`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux updatedb`
