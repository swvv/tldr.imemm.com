# grealpath

> Ova komanda je pseudonim za `-p linux realpath`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux realpath`
