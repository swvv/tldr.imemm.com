# gnice

> Ova komanda je pseudonim za `-p linux nice`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux nice`
