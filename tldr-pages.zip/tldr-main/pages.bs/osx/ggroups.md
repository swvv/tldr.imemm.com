# ggroups

> Ova komanda je pseudonim za `-p linux groups`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux groups`
