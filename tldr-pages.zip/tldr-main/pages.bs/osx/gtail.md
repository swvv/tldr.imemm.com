# gtail

> Ova komanda je pseudonim za `-p linux tail`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr -p linux tail`
