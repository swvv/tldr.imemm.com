# batcat

> Ova komanda je pseudonim za `bat`.
> Više informacija: <https://github.com/sharkdp/bat>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr bat`
