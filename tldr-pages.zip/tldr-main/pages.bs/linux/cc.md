# cc

> Ova komanda je pseudonim za `gcc`.
> Više informacija: <https://gcc.gnu.org>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr gcc`
