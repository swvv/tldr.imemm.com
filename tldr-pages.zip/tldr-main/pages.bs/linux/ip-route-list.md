# ip-route-list

> Ova komanda je pseudonim za `ip-route-show`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr ip-route-show`
