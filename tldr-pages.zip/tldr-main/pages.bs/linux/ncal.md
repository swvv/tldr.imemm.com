# ncal

> Ova komanda je pseudonim za `cal`.
> Više informacija: <https://manned.org/ncal>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr cal`
