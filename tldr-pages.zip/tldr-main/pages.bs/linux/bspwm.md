# bspwm

> Ova komanda je pseudonim za `bspc`.
> Više informacija: <https://github.com/baskerville/bspwm>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr bspc`
