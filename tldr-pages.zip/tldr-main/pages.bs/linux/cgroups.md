# cgroups

> Ova komanda je pseudonim za `cgclassify`.
> Više informacija: <https://www.kernel.org/doc/Documentation/cgroup-v2.txt>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr cgclassify`
