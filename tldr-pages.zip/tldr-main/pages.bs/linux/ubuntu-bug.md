# ubuntu-bug

> Ova komanda je pseudonim za `apport-bug`.
> Više informacija: <https://manned.org/ubuntu-bug>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr apport-bug`
