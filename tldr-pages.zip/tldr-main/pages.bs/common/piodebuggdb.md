# piodebuggdb

> Ova komanda je pseudonim za `pio debug --interface=gdb`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr pio debug`
