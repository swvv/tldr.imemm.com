# python3

> Ova komanda je pseudonim za `python`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr python`
