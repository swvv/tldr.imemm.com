# fossil-forget

> Ova komanda je pseudonim za `fossil rm`.
> Više informacija: <https://fossil-scm.org/home/help/forget>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr fossil rm`
