# gnmic-sub

> Ova komanda je pseudonim za `gnmic subscribe`.
> Više informacija: <https://gnmic.kmrd.dev/cmd/subscribe>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr gnmic subscribe`
