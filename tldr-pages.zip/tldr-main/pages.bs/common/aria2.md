# aria2

> Ova komanda je pseudonim za `aria2c`.

- Pregledaj dokumentaciju za ažuriranu komandu:

`tldr aria2c`
