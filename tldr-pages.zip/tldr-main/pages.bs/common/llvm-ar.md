# llvm-ar

> Ova komanda je pseudonim za `ar`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr ar`
