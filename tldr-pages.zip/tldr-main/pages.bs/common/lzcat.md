# lzcat

> Ova komanda je pseudonim za `xz`.
> Više informacija: <https://manned.org/lzcat>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xz`
