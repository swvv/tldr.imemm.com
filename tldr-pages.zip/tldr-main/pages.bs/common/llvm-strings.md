# llvm-strings

> Ova komanda je pseudonim za `strings`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr strings`
