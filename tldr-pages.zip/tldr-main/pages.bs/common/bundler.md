# bundler

> Ova komanda je pseudonim za `bundle`.
> Više informacija: <https://bundler.io/man/bundle.1.html>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr bundle`
