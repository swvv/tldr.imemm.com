# unlzma

> Ova komanda je pseudonim za `xz`.
> Više informacija: <https://manned.org/unlzma>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xz`
