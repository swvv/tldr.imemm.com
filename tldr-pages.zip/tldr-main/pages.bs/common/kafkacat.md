# kafkacat

> Ova komanda je pseudonim za `kcat`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr kcat`
