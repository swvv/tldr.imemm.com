# unxz

> Ova komanda je pseudonim za `xz`.
> Više informacija: <https://manned.org/unxz>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr xz`
