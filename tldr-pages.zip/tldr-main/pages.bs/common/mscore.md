# mscore

> Ova komanda je pseudonim za `musescore`.
> Više informacija: <https://musescore.org/handbook/command-line-options>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr musescore`
