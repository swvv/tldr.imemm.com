# todoman

> Ova komanda je pseudonim za `todo`.
> Više informacija: <https://todoman.readthedocs.io/>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr todo`
