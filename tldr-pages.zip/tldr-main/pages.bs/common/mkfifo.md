# mkfifo

> Pravi FIFOs (imenovane cijevi).
> Više informacija: <https://www.gnu.org/software/coreutils/mkfifo>.

- Napravi imenovanu cijev na zadatoj putanji:

`mkfifo {{putanja/do/cijev}}`
