# sls

> Ova komanda je pseudonim za `where-object`.
> Više informacija: <https://learn.microsoft.com/powershell/module/microsoft.powershell.utility/select-string>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr where-object`
