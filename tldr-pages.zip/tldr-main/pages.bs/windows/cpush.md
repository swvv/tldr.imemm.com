# cpush

> Ova komanda je pseudonim za `choco-push`.
> Više informacija: <https://docs.chocolatey.org/en-us/create/commands/push>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr choco-push`
