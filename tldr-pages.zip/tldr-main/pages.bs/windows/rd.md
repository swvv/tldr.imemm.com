# rd

> Ova komanda je pseudonim za `rmdir`.
> Više informacija: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr rmdir`
