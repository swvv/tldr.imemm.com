# clist

> Ova komanda je pseudonim za `choco list`.
> Više informacija: <https://docs.chocolatey.org/en-us/choco/commands/list>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr choco list`
