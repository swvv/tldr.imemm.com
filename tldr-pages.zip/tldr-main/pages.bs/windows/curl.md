# curl

> Ova komanda je pseudonim za `curl -p common`.
> Više informacija: <https://curl.se>.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr curl -p common`
