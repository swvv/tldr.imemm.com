# llvm-ar

> Aquest comandament és un àlies de `ar`.

- Veure documentació pel comandament original:

`tldr ar`
