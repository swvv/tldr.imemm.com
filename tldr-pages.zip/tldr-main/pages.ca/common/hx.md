# hx

> Aquest comandament és un àlies de `helix`.

- Veure documentació pel comandament original:

`tldr helix`
