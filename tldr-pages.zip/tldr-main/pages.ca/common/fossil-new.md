# fossil-new

> Aquest comandament és un àlies de `fossil-init`.
> Més informació: <https://fossil-scm.org/home/help/new>.

- Veure documentació pel comandament original:

`tldr fossil-init`
