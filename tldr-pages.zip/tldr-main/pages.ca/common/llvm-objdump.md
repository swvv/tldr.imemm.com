# llvm-objdump

> Aquest comandament és un àlies de `objdump`.

- Veure documentació pel comandament original:

`tldr objdump`
