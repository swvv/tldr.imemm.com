# cd

> Canvia el directori actual.
> Més informació: <https://manned.org/cd>.

- Accedeix al directori donat:

`cd {{camí/al/directori}}`

- Accedeix al directori `home` del usuari actual:

`cd`

- Accedeix al directori pare del directori actual:

`cd ..`

- Accedeix al directori escollit prèviament:

`cd -`
