# kafkacat

> Aquest comandament és un àlies de `kcat`.

- Veure documentació pel comandament original:

`tldr kcat`
