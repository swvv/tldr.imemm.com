# gunlink

> هذا الأمر هو اسم مستعار لـ `-p linux unlink`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux unlink`
