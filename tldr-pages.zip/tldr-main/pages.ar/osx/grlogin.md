# grlogin

> هذا الأمر هو اسم مستعار لـ `-p linux rlogin`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux rlogin`
