# grexec

> هذا الأمر هو اسم مستعار لـ `-p linux rexec`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux rexec`
