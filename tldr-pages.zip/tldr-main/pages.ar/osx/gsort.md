# gsort

> هذا الأمر هو اسم مستعار لـ `-p linux sort`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sort`
