# gftp

> هذا الأمر هو اسم مستعار لـ `-p linux ftp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux ftp`
