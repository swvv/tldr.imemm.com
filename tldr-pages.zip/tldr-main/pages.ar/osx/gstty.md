# gstty

> هذا الأمر هو اسم مستعار لـ `-p linux stty`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux stty`
