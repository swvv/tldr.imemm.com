# gsha256sum

> هذا الأمر هو اسم مستعار لـ `-p linux sha256sum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sha256sum`
