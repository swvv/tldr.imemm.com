# gmd5sum

> هذا الأمر هو اسم مستعار لـ `-p linux md5sum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux md5sum`
