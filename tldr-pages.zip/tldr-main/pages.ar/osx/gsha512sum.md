# gsha512sum

> هذا الأمر هو اسم مستعار لـ `-p linux sha512sum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sha512sum`
