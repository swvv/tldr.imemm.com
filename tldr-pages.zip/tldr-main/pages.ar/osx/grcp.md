# grcp

> هذا الأمر هو اسم مستعار لـ `-p linux rcp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux rcp`
