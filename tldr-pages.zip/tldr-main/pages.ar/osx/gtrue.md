# gtrue

> هذا الأمر هو اسم مستعار لـ `-p linux true`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux true`
