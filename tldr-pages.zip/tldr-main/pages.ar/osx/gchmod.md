# gchmod

> هذا الأمر هو اسم مستعار لـ `-p linux chmod`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux chmod`
