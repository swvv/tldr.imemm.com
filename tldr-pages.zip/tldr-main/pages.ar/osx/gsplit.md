# gsplit

> هذا الأمر هو اسم مستعار لـ `-p linux split`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux split`
