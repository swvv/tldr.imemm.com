# gping

> هذا الأمر هو اسم مستعار لـ `-p linux ping`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux ping`
