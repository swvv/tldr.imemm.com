# gsleep

> هذا الأمر هو اسم مستعار لـ `-p linux sleep`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sleep`
