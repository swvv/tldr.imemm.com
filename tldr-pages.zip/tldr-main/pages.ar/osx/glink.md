# glink

> هذا الأمر هو اسم مستعار لـ `-p linux link`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux link`
