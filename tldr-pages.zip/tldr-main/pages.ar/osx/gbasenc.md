# gbasenc

> هذا الأمر هو اسم مستعار لـ `-p linux basenc`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux basenc`
