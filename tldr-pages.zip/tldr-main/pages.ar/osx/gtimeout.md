# gtimeout

> هذا الأمر هو اسم مستعار لـ `-p linux timeout`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux timeout`
