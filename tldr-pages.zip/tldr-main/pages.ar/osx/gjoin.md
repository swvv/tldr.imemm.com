# gjoin

> هذا الأمر هو اسم مستعار لـ `-p linux join`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux join`
