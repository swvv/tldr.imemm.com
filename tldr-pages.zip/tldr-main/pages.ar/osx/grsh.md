# grsh

> هذا الأمر هو اسم مستعار لـ `-p linux rsh`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux rsh`
