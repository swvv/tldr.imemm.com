# gsha1sum

> هذا الأمر هو اسم مستعار لـ `-p linux sha1sum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sha1sum`
