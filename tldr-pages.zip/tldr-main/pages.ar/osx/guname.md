# guname

> هذا الأمر هو اسم مستعار لـ `-p linux uname`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux uname`
