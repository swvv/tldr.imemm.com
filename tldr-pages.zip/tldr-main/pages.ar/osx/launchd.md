# launchd

> هذا الأمر هو اسم مستعار لـ `launchctl`.
> لمزيد من التفاصيل: <https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/Introduction.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr launchctl`
