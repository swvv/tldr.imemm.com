# gnohup

> هذا الأمر هو اسم مستعار لـ `-p linux nohup`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux nohup`
