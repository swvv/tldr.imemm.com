# gmkfifo

> هذا الأمر هو اسم مستعار لـ `-p linux mkfifo`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux mkfifo`
