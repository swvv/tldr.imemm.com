# gwhoami

> هذا الأمر هو اسم مستعار لـ `-p linux whoami`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux whoami`
