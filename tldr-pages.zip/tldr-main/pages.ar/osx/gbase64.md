# gbase64

> هذا الأمر هو اسم مستعار لـ `-p linux base64`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux base64`
