# gdirname

> هذا الأمر هو اسم مستعار لـ `-p linux dirname`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux dirname`
