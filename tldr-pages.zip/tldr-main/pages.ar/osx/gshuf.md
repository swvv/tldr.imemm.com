# gshuf

> هذا الأمر هو اسم مستعار لـ `-p linux shuf`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux shuf`
