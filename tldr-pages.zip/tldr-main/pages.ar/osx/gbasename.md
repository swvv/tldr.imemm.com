# gbasename

> هذا الأمر هو اسم مستعار لـ `-p linux basename`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux basename`
