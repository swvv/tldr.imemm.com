# genv

> هذا الأمر هو اسم مستعار لـ `-p linux env`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux env`
