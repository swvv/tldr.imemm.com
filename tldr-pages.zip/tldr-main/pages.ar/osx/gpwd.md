# gpwd

> هذا الأمر هو اسم مستعار لـ `-p linux pwd`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux pwd`
