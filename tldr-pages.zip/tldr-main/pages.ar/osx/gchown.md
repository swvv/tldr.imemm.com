# gchown

> هذا الأمر هو اسم مستعار لـ `-p linux chown`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux chown`
