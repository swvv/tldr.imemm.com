# gfactor

> هذا الأمر هو اسم مستعار لـ `-p linux factor`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux factor`
