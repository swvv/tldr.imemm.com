# ghostname

> هذا الأمر هو اسم مستعار لـ `-p linux hostname`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux hostname`
