# ginstall

> هذا الأمر هو اسم مستعار لـ `-p linux install`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux install`
