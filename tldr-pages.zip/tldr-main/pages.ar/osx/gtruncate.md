# gtruncate

> هذا الأمر هو اسم مستعار لـ `-p linux truncate`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux truncate`
