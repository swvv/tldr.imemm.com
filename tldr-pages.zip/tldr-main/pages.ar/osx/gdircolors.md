# gdircolors

> هذا الأمر هو اسم مستعار لـ `-p linux dircolors`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux dircolors`
