# gsha224sum

> هذا الأمر هو اسم مستعار لـ `-p linux sha224sum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux sha224sum`
