# gnproc

> هذا الأمر هو اسم مستعار لـ `-p linux nproc`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux nproc`
