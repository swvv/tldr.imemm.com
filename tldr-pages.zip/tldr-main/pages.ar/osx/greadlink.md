# greadlink

> هذا الأمر هو اسم مستعار لـ `-p linux readlink`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux readlink`
