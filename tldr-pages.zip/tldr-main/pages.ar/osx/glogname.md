# glogname

> هذا الأمر هو اسم مستعار لـ `-p linux logname`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux logname`
