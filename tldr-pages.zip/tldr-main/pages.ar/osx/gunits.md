# gunits

> هذا الأمر هو اسم مستعار لـ `-p linux units`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux units`
