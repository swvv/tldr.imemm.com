# gcksum

> هذا الأمر هو اسم مستعار لـ `-p linux cksum`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux cksum`
