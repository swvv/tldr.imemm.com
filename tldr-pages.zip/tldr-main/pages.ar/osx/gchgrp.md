# gchgrp

> هذا الأمر هو اسم مستعار لـ `-p linux chgrp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr -p linux chgrp`
