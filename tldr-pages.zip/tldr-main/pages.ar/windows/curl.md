# curl

> هذا الأمر هو اسم مستعار لـ `curl -p common`.
> لمزيد من التفاصيل: <https://curl.se>.

- إعرض التوثيقات للأمر الأصلي:

`tldr curl -p common`
