# rd

> هذا الأمر هو اسم مستعار لـ `rmdir`.
> لمزيد من التفاصيل: <https://learn.microsoft.com/windows-server/administration/windows-commands/rd>.

- إعرض التوثيقات للأمر الأصلي:

`tldr rmdir`
