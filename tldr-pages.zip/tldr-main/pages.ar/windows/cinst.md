# cinst

> هذا الأمر هو اسم مستعار لـ `choco install`.
> لمزيد من التفاصيل: <https://docs.chocolatey.org/en-us/choco/commands/install>.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco install`
