# alternatives

> هذا الأمر هو اسم مستعار لـ `update-alternatives`.
> لمزيد من التفاصيل: <https://manned.org/alternatives>.

- إعرض التوثيقات للأمر الأصلي:

`tldr update-alternatives`
