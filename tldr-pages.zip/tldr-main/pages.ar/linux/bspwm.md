# bspwm

> هذا الأمر هو اسم مستعار لـ `bspc`.
> لمزيد من التفاصيل: <https://github.com/baskerville/bspwm>.

- إعرض التوثيقات للأمر الأصلي:

`tldr bspc`
