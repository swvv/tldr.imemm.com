# ubuntu-bug

> هذا الأمر هو اسم مستعار لـ `apport-bug`.
> لمزيد من التفاصيل: <https://manned.org/ubuntu-bug>.

- إعرض التوثيقات للأمر الأصلي:

`tldr apport-bug`
