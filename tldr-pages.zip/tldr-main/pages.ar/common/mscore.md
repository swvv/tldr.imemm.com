# mscore

> هذا الأمر هو اسم مستعار لـ `musescore`.
> لمزيد من التفاصيل: <https://musescore.org/handbook/command-line-options>.

- إعرض التوثيقات للأمر الأصلي:

`tldr musescore`
