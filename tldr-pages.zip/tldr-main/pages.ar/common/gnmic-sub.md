# gnmic-sub

> هذا الأمر هو اسم مستعار لـ `gnmic subscribe`.
> لمزيد من التفاصيل: <https://gnmic.kmrd.dev/cmd/subscribe>.

- إعرض التوثيقات للأمر الأصلي:

`tldr gnmic subscribe`
