# clamav

> هذا الأمر هو اسم مستعار لـ `clamdscan`.
> لمزيد من التفاصيل: <https://www.clamav.net>.

- إعرض التوثيقات للأمر الأصلي:

`tldr clamdscan`
