# bundler

> هذا الأمر هو اسم مستعار لـ `bundle`.
> لمزيد من التفاصيل: <https://bundler.io/man/bundle.1.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr bundle`
