# tlmgr-arch

> هذا الأمر هو اسم مستعار لـ `tlmgr platform`.
> لمزيد من التفاصيل: <https://www.tug.org/texlive/tlmgr.html>.

- إعرض التوثيقات للأمر الأصلي:

`tldr tlmgr platform`
