# tldrl

> هذا الأمر هو اسم مستعار لـ `tldr-lint`.
> لمزيد من التفاصيل: <https://github.com/tldr-pages/tldr-lint>.

- إعرض التوثيقات للأمر الأصلي:

`tldr tldr-lint`
