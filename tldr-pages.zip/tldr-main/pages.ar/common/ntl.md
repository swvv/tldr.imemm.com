# ntl

> هذا الأمر هو اسم مستعار لـ `netlify`.
> لمزيد من التفاصيل: <https://cli.netlify.com>.

- إعرض التوثيقات للأمر الأصلي:

`tldr netlify`
