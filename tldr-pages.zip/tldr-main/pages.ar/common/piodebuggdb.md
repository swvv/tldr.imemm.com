# piodebuggdb

> هذا الأمر هو اسم مستعار لـ `pio debug`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pio debug`
